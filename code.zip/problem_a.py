import requests


def popular_count():
    URL = 'https://api.themoviedb.org/3/movie/popular?api_key=e61e2e3c124b0718f734281454239f47&language=ko-KR&page=1'
    response = requests.get(URL).json()
    cnt = 0
    for item in response['results']:
        cnt += 1

    return cnt





# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    """
    popular 영화목록의 개수 반환
    """
    print(popular_count())
    # 20
