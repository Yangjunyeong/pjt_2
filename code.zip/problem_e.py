import requests
from pprint import pprint


def credits(title):
    URL = f'https://api.themoviedb.org/3/search/movie?api_key=e61e2e3c124b0718f734281454239f47&language=en-US&query={title}&page=1&include_adult=false'
    
    response = requests.get(URL).json()
    try:
        search_mov = response['results'][0]
        movie_id = search_mov['id']
        URL2 = f'https://api.themoviedb.org/3/movie/{movie_id}/credits?api_key=e61e2e3c124b0718f734281454239f47&language=ko-KR'
        
        response_credits = requests.get(URL2).json()
        
        cast_lst = []
        directing_lst = []
        for item in response_credits['cast']:
            
            if item['cast_id'] < 10:
                cast_lst.append(item['name'])
        for i in response_credits['crew']:     
            if i['department'] == 'Directing':
                directing_lst.append(i['name'])

        cast_directing_dict = {
            'cast': cast_lst,
            'directing': directing_lst}  
        return cast_directing_dict


    except:
        return None    


# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    """
    제목에 해당하는 영화가 있으면 해당 영화 id를 통해 영화 상세정보를 검색하여 주연배우 목록(cast)과 스태프(crew) 중 연출진 목록을 반환
    영화 id 검색에 실패할 경우 None을 반환
    """
    pprint(credits('기생충'))
    # {'cast': ['Song Kang-ho', 'Lee Sun-kyun', ..., 'Jang Hye-jin'], 'crew': ['Bong Joon-ho', 'Park Hyun-cheol', ..., 'Yoon Young-woo']}
    pprint(credits('검색할 수 없는 영화'))
    # None
