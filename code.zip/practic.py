import requests

URL = 'https://api.themoviedb.org/3/movie/popular?api_key=e61e2e3c124b0718f734281454239f47&language=ko-KR&page=1'
response = requests.get(URL).json()

print(response)
f'https://api.themoviedb.org/3/search/movie?api_key=e61e2e3c124b0718f734281454239f47&language=en-US&query={title}&page=1&include_adult=false'
